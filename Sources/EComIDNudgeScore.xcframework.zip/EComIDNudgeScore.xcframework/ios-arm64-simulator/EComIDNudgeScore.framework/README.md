# eComID Widgets

This library contains the widgets that our clients can use to integrate our solutions into their iOS apps. To understand how each of the widgets work and usage guide, follow their documentation at docs.ecomid.com

## Installation
This library is available internally and to our clients through XCFrameworks. The different schemas setup in the project set up the different products we give them.

## Compatibility
We support iOS 17 and upwards, if we feel in the future that we can drop the support of old versions of iOS, this will be announced in the release notes.
